public class Bullets {





    public void move(){

    }




}
