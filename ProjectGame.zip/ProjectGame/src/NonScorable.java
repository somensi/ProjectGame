public interface NonScorable {
}
