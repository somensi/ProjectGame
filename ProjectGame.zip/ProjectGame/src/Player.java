public class Player {

    private boolean status;
    private int countShots;
    private int score;


    public Player(){

    }


    public void move(){

    }

    public void shoot(){

    }




}
