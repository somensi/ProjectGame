public interface Scorable {








}
