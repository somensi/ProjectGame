public abstract class Target {


    private boolean destroyed;


    public boolean isDestroyed() {
        return destroyed;
    }

    public void startPosition(){

    }

    public void move(){

    }




}
