public class TargetOne extends Target implements Scorable {
}
