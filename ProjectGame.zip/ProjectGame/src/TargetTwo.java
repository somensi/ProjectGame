public class TargetTwo extends Target implements NonScorable {





}
